import{A as c,e as t}from"./mermaid-parser.core.BRa7lOzZ.js";export{c as ArchitectureModule,t as createArchitectureServices};
//# sourceMappingURL=architecture-I3QFYML2.-SPLi6nC.js.map
