import{G as a,f as G}from"./mermaid-parser.core.BRa7lOzZ.js";export{a as GitGraphModule,G as createGitGraphServices};
//# sourceMappingURL=gitGraph-YCYPL57B.znBhblme.js.map
