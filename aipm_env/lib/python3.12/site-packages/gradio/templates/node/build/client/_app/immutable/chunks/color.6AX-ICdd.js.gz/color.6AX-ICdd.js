import{v as o}from"./2.qheU58Mf.js";const t=r=>o[r%o.length];export{t as g};
//# sourceMappingURL=color.6AX-ICdd.js.map
