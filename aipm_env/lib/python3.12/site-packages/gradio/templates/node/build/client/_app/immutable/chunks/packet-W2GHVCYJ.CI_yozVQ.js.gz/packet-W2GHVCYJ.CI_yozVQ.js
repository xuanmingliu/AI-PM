import{P as c,a as r}from"./mermaid-parser.core.BRa7lOzZ.js";export{c as PacketModule,r as createPacketServices};
//# sourceMappingURL=packet-W2GHVCYJ.CI_yozVQ.js.map
