import{Z as e,_ as n}from"../chunks/2.qheU58Mf.js";export{e as component,n as universal};
//# sourceMappingURL=2.B5-w01VP.js.map
