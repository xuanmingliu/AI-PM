import{s as a,S as t,b as r,a as s}from"./chunk-4IRHCMPZ.B-QMxTpT.js";import{_ as i}from"./mermaid.core.Cl4EJVJd.js";var _={parser:a,get db(){return new t(2)},renderer:r,styles:s,init:i(e=>{e.state||(e.state={}),e.state.arrowMarkerAbsolute=e.arrowMarkerAbsolute},"init")};export{_ as diagram};
//# sourceMappingURL=stateDiagram-v2-WR7QG3WR.CwAo9C-w.js.map
